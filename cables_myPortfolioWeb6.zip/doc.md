## Patch Variables:

* __boolAnimValue__ ```Number```
* __mouseSnap__ ```Number```
* __mouseX__ ```Number```
* __mouseX__ ```Number```
* __mouseY__ ```Number```
* __mouseY__ ```Number```
* __snapBoolean__ ```Number```

